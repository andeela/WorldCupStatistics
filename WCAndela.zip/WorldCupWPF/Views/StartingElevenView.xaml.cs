﻿using DAL.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WorldCupForms;


namespace WorldCupWPF.Views
{
    /// <summary>
    /// Interaction logic for StartingElevenView.xaml
    /// </summary>
    public partial class StartingElevenView : UserControl
    {

        public StartingElevenView()
        {
            InitializeComponent();
        }

        public void LoadData(List<Player> startingEleven, string nationalTeam, string opponent, int wins, int loses, int draws, int goalsScored, int goalsReceived, int goalDifference)
        {
            tbNationalTeam.Text = $"{nationalTeam} - all around stats";
            tbWins.Text = $"Wins: {wins}";
            tbLoses.Text = $"Losses: {loses}";
            tbDraws.Text = $"Draws: {draws}";
            tbGoalsScored.Text = $"Goals scored: {goalsScored}";
            tbGoalsRecieved.Text = $"Goals received: {goalsReceived}";
            tbGoalDifference.Text = $"Goal difference: {goalDifference}";

            tbStartingEleven.Text = $"Starting Eleven against {opponent}";

            gridStartingEleven.Children.Clear();

            var formation = DetermineFormation(startingEleven);

            ArrangePlayers(startingEleven, formation);
        }

        private string DetermineFormation(List<Player> players)
        {
            int defenders = players.Count(p => p.Position == "Defender");
            int midfield = players.Count(p => p.Position == "Midfield");
            int forward = players.Count(p => p.Position == "Forward");

            return $"{defenders}-{midfield}-{forward}";
        }

        private void ArrangePlayers(List<Player> players, string formation)
        {
            var positions = new Dictionary<string, List<Point>>
            {
                { "4-4-2", new List<Point> { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(1, 3), new Point(2, 3) } },
                { "3-4-3", new List<Point> { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(1, 2), new Point(0, 3), new Point(1, 3), new Point(2, 3), new Point(1, 4), new Point(0, 5), new Point(2, 5) } },
                { "5-4-1", new List<Point> { new Point(2, 0), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(4, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(2, 3), new Point(1, 4) } },
                { "4-3-3", new List<Point> { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(1, 3), new Point(2, 3) } },
                { "3-5-2", new List<Point> { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(1, 2), new Point(0, 3), new Point(1, 3), new Point(2, 3), new Point(0, 4), new Point(2, 4), new Point(1, 5) } },
                { "2-4-4", new List<Point> { new Point(0, 0), new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(0, 2), new Point(1, 2), new Point(0, 3), new Point(1, 3), new Point(0, 4), new Point(1, 4), new Point(0, 5) } },
                { "4-5-1", new List<Point> { new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(2, 3), new Point(1, 4) } },
                { "5-3-2", new List<Point> { new Point(2, 0), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(4, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(1, 3), new Point(3, 3) } },
                { "2-5-3", new List<Point> { new Point(0, 0), new Point(1, 0), new Point(0, 1), new Point(1, 1), new Point(0, 2), new Point(1, 2), new Point(0, 3), new Point(1, 3), new Point(0, 4), new Point(1, 4), new Point(0, 5) } }
            };


            if (positions.TryGetValue(formation, out var positionList)) 
            {
                var goalie = players.First(p => p.Position == "Goalie");
                PlayerControlWPF goalieControl = new PlayerControlWPF(goalie.Name, goalie.ShirtNumber);
                Grid.SetRow(goalieControl, 0);
                Grid.SetColumn(goalieControl, 1);
                gridStartingEleven.Children.Add(goalieControl);

                var otherPlayer = players.Where(p => p.Position != "Goalie").ToList();
                for (int i = 0; i < otherPlayer.Count; i++)
                {
                    var player = otherPlayer[i];
                    PlayerControlWPF playerControl = new PlayerControlWPF(player.Name, player.ShirtNumber);
                    var position = positionList[i];
                    Grid.SetRow(playerControl, (int)position.Y);
                    Grid.SetColumn(playerControl, (int)position.X);
                    gridStartingEleven.Children.Add(playerControl);
                }
            }
            else
            {
                Debug.WriteLine("Formation not supported");
            }
        }
    }
}