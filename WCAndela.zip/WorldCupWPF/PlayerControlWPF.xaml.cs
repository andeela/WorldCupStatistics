﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WorldCupForms;

namespace WorldCupWPF
{
    /// <summary>
    /// Interaction logic for PlayerControlWPF.xaml
    /// </summary>
    /*public partial class PlayerControlWPF : UserControl
    {
        public static readonly DependencyProperty PlayerNameProperty =
            DependencyProperty.Register("PlayerName", typeof(string), typeof(PlayerControlWPF), new PropertyMetadata(""));

        public static readonly DependencyProperty PositionProperty =
            DependencyProperty.Register("Position", typeof(string), typeof(PlayerControlWPF), new PropertyMetadata(""));

        public static readonly DependencyProperty ShirtNumberProperty =
            DependencyProperty.Register("ShirtNumber", typeof(int), typeof(PlayerControlWPF), new PropertyMetadata(0));

        public static readonly DependencyProperty IsCaptainProperty =
            DependencyProperty.Register("IsCaptain", typeof(bool), typeof(PlayerControlWPF), new PropertyMetadata(false));

        public static readonly DependencyProperty IsFavouriteProperty =
            DependencyProperty.Register("IsFavourite", typeof(bool), typeof(PlayerControlWPF), new PropertyMetadata(false));

        public static readonly DependencyProperty ImagePathProperty =
            DependencyProperty.Register("ImagePath", typeof(string), typeof(PlayerControlWPF), new PropertyMetadata(null, OnImagePathChanged));

        private Image playerIcon;
        private TextBlock playerInfo;
        private ContextMenu contextMenu;

        public PlayerControlWPF()
        {
            InitializeControl();
            InitializeContextMenu();
        }

        public PlayerControlWPF(string playerName, string position, int shirtNumber, bool isCaptain, bool isFavourite, string imagePath)
        {
            PlayerName = playerName;
            Position = position;
            ShirtNumber = shirtNumber;
            IsCaptain = isCaptain;
            IsFavourite = isFavourite;
            ImagePath = imagePath;

            InitializeControl();
            InitializeContextMenu();
        }

        public string PlayerName
        {
            get { return (string)GetValue(PlayerNameProperty); }
            set { SetValue(PlayerNameProperty, value); }
        }

        public string Position
        {
            get { return (string)GetValue(PositionProperty); }
            set { SetValue(PositionProperty, value); }
        }

        public int ShirtNumber
        {
            get { return (int)GetValue(ShirtNumberProperty); }
            set { SetValue(ShirtNumberProperty, value); }
        }

        public bool IsCaptain
        {
            get { return (bool)GetValue(IsCaptainProperty); }
            set { SetValue(IsCaptainProperty, value); }
        }

        public bool IsFavourite
        {
            get { return (bool)GetValue(IsFavouriteProperty); }
            set { SetValue(IsFavouriteProperty, value); }
        }

        public string ImagePath
        {
            get { return (string)GetValue(ImagePathProperty); }
            set { SetValue(ImagePathProperty, value); }
        }

        private void InitializeControl()
        {
            playerIcon = new Image
            {
                Width = 60,
                Height = 60,
                Stretch = Stretch.UniformToFill,
                Margin = new Thickness(10, 10, 10, 0)
            };
            playerIcon.SetBinding(Image.SourceProperty, new Binding("ImagePath"));

            playerInfo = new TextBlock
            {
                TextAlignment = TextAlignment.Center,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 70, 0, 0)
            };
            playerInfo.SetBinding(TextBlock.TextProperty, new Binding("PlayerInfo"));

            Content = new Grid
            {
                Width = 80,
                Height = 100,
                Margin = new Thickness(5)
            };
            ((Grid)Content).Children.Add(playerIcon);
            ((Grid)Content).Children.Add(playerInfo);

            MouseLeftButtonDown += PlayerControlWPF_MouseLeftButtonDown;
        }

        private void InitializeContextMenu()
        {
            contextMenu = new ContextMenu();
            MenuItem markFavouriteMenuItem = new MenuItem() { Header = "Mark as Favourite" };
            markFavouriteMenuItem.Click += MarkFavouriteMenuItem_Click;
            contextMenu.Items.Add(markFavouriteMenuItem);

            MenuItem showInfoMenuItem = new MenuItem() { Header = "Show More Info" };
            showInfoMenuItem.Click += ShowInfoMenuItem_Click;
            contextMenu.Items.Add(showInfoMenuItem);

            ContextMenu = contextMenu;
        }

        private void MarkFavouriteMenuItem_Click(object sender, RoutedEventArgs e)
        {
            IsFavourite = !IsFavourite;
        }

        private void ShowInfoMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Player: {PlayerName}\nPosition: {Position}\nShirt Number: {ShirtNumber}\nIs Captain: {IsCaptain}\nIs Favourite: {IsFavourite}");
        }

        private void PlayerControlWPF_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)  // Double-click action
            {
                MessageBox.Show($"Double-clicked on {PlayerName}");
            }
        }

        private static void OnImagePathChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is PlayerControlWPF playerControl && e.NewValue is string imagePath)
            {
                if (!string.IsNullOrEmpty(imagePath))
                {
                    playerControl.playerIcon.Source = new BitmapImage(new Uri(imagePath));
                }
                else
                {
                    // Set default image or handle no image scenario
                    playerControl.playerIcon.Source = new BitmapImage(new Uri("/Resources/defaultPlayerImage.png", UriKind.Relative));
                }
            }
        }
    }*/
    public partial class PlayerControlWPF : UserControl
    {
        public static readonly DependencyProperty PlayerNameProperty =
            DependencyProperty.Register("PlayerName", typeof(string), typeof(PlayerControlWPF), new PropertyMetadata(""));

        public static readonly DependencyProperty ShirtNumberProperty =
            DependencyProperty.Register("ShirtNumber", typeof(int), typeof(PlayerControlWPF), new PropertyMetadata(0));

        public static readonly DependencyProperty ImagePathProperty =
            DependencyProperty.Register("ImagePath", typeof(string), typeof(PlayerControlWPF), new PropertyMetadata(null, OnImagePathChanged));

        public string PlayerName
        {
            get { return (string)GetValue(PlayerNameProperty); }
            set { SetValue(PlayerNameProperty, value); }
        }

        public int ShirtNumber
        {
            get { return (int)GetValue(ShirtNumberProperty); }
            set { SetValue(ShirtNumberProperty, value); }
        }

        public string ImagePath
        {
            get { return (string)GetValue(ImagePathProperty); }
            set { SetValue(ImagePathProperty, value); }
        }

        public PlayerControlWPF()
        {
            InitializeComponent();
            DataContext = this; // Set the DataContext to this UserControl
        }
        public PlayerControlWPF(string playerName, int shirtNumber)
        : this()
    {
        PlayerName = playerName;
        ShirtNumber = shirtNumber;
    }

        private static void OnImagePathChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is PlayerControlWPF playerControl && e.NewValue is string imagePath)
            {
                if (!string.IsNullOrEmpty(imagePath))
                {
                    playerControl.imgPlayer.Source = new BitmapImage(new Uri(imagePath));
                }
                else
                {
                    // Set default image or handle no image scenario
                    playerControl.imgPlayer.Source = new BitmapImage(new Uri("/Images/playerIcon.png", UriKind.Relative));
                }
            }
        }
    }

}

