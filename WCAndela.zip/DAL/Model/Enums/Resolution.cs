﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Model.Enums
{
    public enum Resolution
    {
        FULLSCREEN, 
        /*r1920x1000,
        r1600x1200,*/
        r720x480
    }
}
